#ifndef _SIGNUP_H_
#define _SIGNUP_H_

void signup_bkpaint(int language);
int signup_page(int language);
void ok_button_light(void);
void ok_button_recover(void);
void show_rule_english();
void show_rule_chinese();

#endif
