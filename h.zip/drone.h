#ifndef _DRONE_H_
#define _DRONE_H_

void drone_screen(int language);
int drone_page(char *username,char *drone_name_now,DRONEINFO *drone,int language);
void open_file2(int language);

#endif