#ifndef _PLANT_H_
#define _PLANT_H_

void paint_field( int record[21][26] ,char *nowfield,int language);
void plant_screen( int record[21][26] ,char *nowfield,int language);
int plant_page(char *username,char *nowfield,int language);
void put_ok_button(int flag);


#endif
