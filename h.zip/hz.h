#ifndef _HZ_H_
#define _HZ_H_

void puthz(int x, int y, char *s, int flag, int part, int color);
#endif