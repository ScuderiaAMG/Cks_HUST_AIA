#ifndef _PESTICIDE_H_
#define _PESTICIDE_H_

void pesticide_screen(int language);
int pesticide_page(char *username,char *now_pesticide,int language);

#endif