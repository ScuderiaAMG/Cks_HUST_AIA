#ifndef _LANGUAGE_H_
#define _LANGUAGE_H_

int language_page(int *language);

#endif