#ifndef _DRONEFUNC_H_
#define _DRONEFUNC_H_

void dronefunc_screen(int language);
int drone_list_page(char *username,DRONEINFO *nowdrone,int language);

#endif