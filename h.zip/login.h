#ifndef _LOGIN_H_
#define _LOGIN_H_

#include "public.h"

void login_bkpaint(int language);//画登录页面背�?
void signup_button_recover(int language);
void signup_button_light(int language);
void put_flower(int x,int y,int pix,int COLOR);
void ok_button_light(void);
void ok_button_recover(void);
int login_page(INFO *temp,int language);

#endif