#ifndef _QUIT_H_
#define _QUIT_H_

void quit_page(void);

#endif