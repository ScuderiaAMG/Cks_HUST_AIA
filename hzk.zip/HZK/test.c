//#include <stdio.h>
//#include <dir.h>    // BorlandĿ¼����ͷ�ļ�
//#include <string.h>
//#include <graphics.h>
//#include <dos.h>    // �ӳٺ���
//
//
//
//// ״̬ö��
//enum { SELECT_USER, SELECT_CATEGORY, SELECT_FILE, SHOW_CONTENT };
//
//// ��������봦������
//int draw_user_list(const char users[][13], int count);
//int draw_category_list();
//int draw_file_list(const char files[][13], int count);
//void show_file_content(const char* path);
//
//int logs_page(int language) 
//{
//    static int state = SELECT_USER; // ��ǰ����״̬
//    static char currentUser[13] = { 0 }; // ��ǰѡ���û�
//    static char currentCategory[13] = { 0 }; // ��ǰѡ�����
//    static char currentFile[13] = { 0 }; // ��ǰѡ���ļ�
//    struct ffblk ffblk;
//    char path[128];
//    int done;
//
//    // ��ѭ��
//    while (1) {
//        cleardevice();
//
//        /* ���Ʒ��ذ�ť */
//        setfillstyle(SOLID_FILL, RED);
//        bar(600, 2, 640, 42);
//        rectangle(600, 2, 640, 42);
//
//        /* ״̬���� */
//        switch (state) 
//        {
//        case SELECT_USER: 
//        {
//            // ɨ��C:\DATAĿ¼��ȡ�û��б�
//            char users[MAX_ITEMS][13] = { 0 };
//            int userCount = 0;
//
//            done = findfirst("C:\\DATA\\*.*", &ffblk, FA_DIREC);
//            while (!done && userCount < MAX_ITEMS) 
//            {
//                if ((ffblk.ff_attrib & FA_DIREC) && strcmp(ffblk.ff_name, ".") && strcmp(ffblk.ff_name, "..")) 
//                {
//                    strcpy(users[userCount++], ffblk.ff_name);
//                }
//                done = findnext(&ffblk);
//            }
//
//            // �����û��б�����ȡѡ��
//            int selected = draw_user_list(users, userCount);
//            if (selected != -1) 
//            {
//                strcpy(currentUser, users[selected]);
//                state = SELECT_CATEGORY;
//            }
//            break;
//        }
//
//        case SELECT_CATEGORY: 
//        {
//            // ���ƹ̶��������
//            int selected = draw_category_list();
//            const char* categories[] = { "DRONE", "FIELD", "PESTICIDE" };
//            if (selected != -1) 
//            {
//                strcpy(currentCategory, categories[selected]);
//                state = SELECT_FILE;
//            }
//            break;
//        }
//
//        case SELECT_FILE: 
//        {
//            // ����·����C:\DATA\�û�\���\*.dat
//            sprintf(path, "C:\\DATA\\%s\\%s\\*.dat",currentUser, currentCategory);
//
//            char files[MAX_ITEMS][13] = { 0 };
//            int fileCount = 0;
//
//            done = findfirst(path, &ffblk, 0);
//            while (!done && fileCount < MAX_ITEMS) 
//            {
//                strcpy(files[fileCount++], ffblk.ff_name);
//                done = findnext(&ffblk);
//            }
//
//            // �����ļ��б�
//            int selected = draw_file_list(files, fileCount);
//            if (selected != -1) 
//            {
//                strcpy(currentFile, files[selected]);
//                state = SHOW_CONTENT;
//            }
//            break;
//        }
//
//        case SHOW_CONTENT: 
//        {
//            // ���������ļ�·��
//            sprintf(path, "C:\\DATA\\%s\\%s\\%s", currentUser, currentCategory, currentFile);
//            show_file_content(path);
//            break;
//        }
//        }
//
//        /* ��������¼� */
//        newmouse(&MouseX, &MouseY, &press);
//
//        // ���ذ�ť���
//        if (mouse_press(600, 2, 640, 42) == 1)
//        {
//            fclose(filelog);
//            return HOME;
//        }
//    }
//}
//
///*---------- ������ƺ��� ----------*/
//int draw_user_list(const char users[][13], int count) 
//{
//    int i, y;
//    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 3);
//
//    // ���Ʊ���
//    outtextxy(50, 30, "Select User:");
//
//    // �����û��б�
//    for (i = 0; i < count; i++) 
//    {
//        y = 80 + i * 40;
//        rectangle(50, y, 50 + BTN_WIDTH, y + BTN_HEIGHT);
//        outtextxy(60, y + 8, users[i]);
//    }
//
//    // �����
//    newmouse(&MouseX, &MouseY, &press);
//    for (i = 0; i < count; i++) {
//        y = 80 + i * 40;
//        if (MouseX > 50 && MouseX < 50 + BTN_WIDTH && MouseY > y && MouseY < y + BTN_HEIGHT) 
//        {
//            return i;
//        }
//    }
//    return -1;
//}
//
//int draw_category_list() 
//{
//    int i, y;
//    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 3);
//    outtextxy(50, 30, "Select Category:");
//
//    const char* categories[] = { "DRONE", "FIELD", "PESTICIDE" };
//    for (i = 0; i < 3; i++) 
//    {
//        y = 80 + i * 40;
//        rectangle(50, y, 50 + BTN_WIDTH, y + BTN_HEIGHT);
//        outtextxy(60, y + 8, categories[i]);
//    }
//
//    // �����
//    newmouse(&MouseX, &MouseY, &press);
//    for (i = 0; i < 3; i++) 
//    {
//        y = 80 + i * 40;
//        if (MouseX > 50 && MouseX < 50 + BTN_WIDTH && MouseY > y && MouseY < y + BTN_HEIGHT) 
//        {
//            return i;
//        }
//    }
//    return -1;
//}
//
//void show_file_content(const char* path) 
//{
//    FILE* fp = fopen(path, "rb");
//    char buffer[128];
//    int y = 50;
//    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 3);
//    if (!fp) 
//    {
//        outtextxy(50, 50, "Error opening file!");
//        return;
//    }
//
//    // ��ȡ����ʾ����
//   
//    while (fgets(buffer, sizeof(buffer), fp) 
//    {
//        outtextxy(50, y, buffer);
//        y += 20;
//        if (y > 400) break; // ������Ļֹͣ
//    }
//    fclose(fp);
//}
//
///*---------- �����ļ��б����ƺ��� ----------*/
//int draw_file_list(const char files[][13], int count)
//{
//    int i, y;
//    settextstyle(SANS_SERIF_FONT, HORIZ_DIR, 3);
//
//    // ���Ʊ���
//    outtextxy(50, 30, "Select File:");
//
//    // �����ļ��б�
//    for (i = 0; i < count; i++)
//    {
//        y = 80 + i * 40;
//        rectangle(50, y, 50 + BTN_WIDTH, y + BTN_HEIGHT);
//        outtextxy(60, y + 8, files[i]);
//    }
//
//    // �����
//    newmouse(&MouseX, &MouseY, &press);
//    for (i = 0; i < count; i++)
//    {
//        y = 80 + i * 40;
//        if (MouseX > 50 && MouseX < 50 + BTN_WIDTH && MouseY > y && MouseY < y + BTN_HEIGHT)
//        {
//            return i;
//        }
//    }
//    return -1;
//}
int logs_page(int language)
{
    FILE* filelog = NULL;
    static int state = SELECT_USER;
    static char currentUser[13] = { 0 };
    static char currentCategory[13] = { 0 };
    static char currentFile[13] = { 0 };
    struct ffblk ffblk;
    char path[128];
    int done;
    int selected;
    int userCount = 0;
    int fileCount = 0;
    int prevState = -1;  // ������������ǰһ��״̬
    char users[MAX_ITEMS][13] = { 0 };
    char files[MAX_ITEMS][13] = { 0 };
    const char* categories[] = { "DRONE", "FIELD", "PESTICIDE" };

    clrmous(MouseX, MouseY);
    setbkcolor(WHITE);
    cleardevice();
    mouseinit();

    // ��ѭ��
    while (1)
    {
        newmouse(&MouseX, &MouseY, &press);

        if (state != prevState) {    // ֻ����״̬�仯ʱ������
            cleardevice();           // �����Ļ
            prevState = state;       // ����ǰһ�ε�״̬
        }

        switch (state)
        {
        case SELECT_USER:
            done = findfirst("C:\\DATA\\*.*", &ffblk, FA_DIREC);
            while (!done && userCount < MAX_ITEMS)
            {
                if ((ffblk.ff_attrib & FA_DIREC) && strcmp(ffblk.ff_name, ".") && strcmp(ffblk.ff_name, ".."))
                {
                    strcpy(users[userCount++], ffblk.ff_name);
                }
                done = findnext(&ffblk);
            }

            selected = draw_user_list(users, userCount, language);
            if (selected != -1)
            {
                strncpy(currentUser, users[selected], sizeof(currentUser) - 1);
                currentUser[sizeof(currentUser) - 1] = '\0';
                delay(50);  // ������ʱ������ˢ��Ƶ��
                state = SELECT_CATEGORY;
            }
            break;

        case SELECT_CATEGORY:
            selected = draw_category_list(language);
            if (selected != -1)
            {
                strcpy(currentCategory, categories[selected]);
                delay(50);  // ������ʱ������ˢ��Ƶ��
                state = SELECT_FILE;
            }
            break;

        case SELECT_FILE:
            // ����·����C:\\DATA\\�û�\\���
            sprintf(path, "C:\\DATA\\%s\\%s", currentUser, currentCategory);

            // �г��ļ����е��������ļ��к� .dat �ļ�
            done = findfirst(path, &ffblk, FA_DIREC);
            while (!done && fileCount < MAX_ITEMS)
            {
                if ((ffblk.ff_attrib & FA_DIREC) && strcmp(ffblk.ff_name, ".") && strcmp(ffblk.ff_name, ".."))
                {
                    // �������ļ���
                    strcpy(files[fileCount++], ffblk.ff_name);
                }
                else if (strstr(ffblk.ff_name, ".dat")) {
                    // ���� .dat �ļ�
                    strcpy(files[fileCount++], ffblk.ff_name);
                }
                done = findnext(&ffblk);
            }

            selected = draw_file_list(files, fileCount, language);
            if (selected != -1)
            {
                // �жϵ�������ļ��л��� .dat �ļ�
                if (strstr(files[selected], ".dat")) {
                    // ����� .dat �ļ�����ʾ�ļ�����
                    strcpy(currentFile, files[selected]);
                    delay(50);  // ������ʱ������ˢ��Ƶ��
                    state = SHOW_CONTENT;
                }
                else {
                    // ������ļ��У�������ļ���
                    strcat(path, "\\");
                    strcat(path, files[selected]);
                    state = SELECT_FILE;  // ���¼��ظ��ļ��е�����
                }
            }
            break;

        case SHOW_CONTENT:
            // ���������ļ�·��
            sprintf(path, "C:\\DATA\\%s\\%s\\%s", currentUser, currentCategory, currentFile);
            show_file_content(path, language);
            delay(50);  // ������ʱ������ˢ��Ƶ��
            break;
        }

        // ���ذ�ť���
        if (mouse_press(600, 2, 640, 42) == 1)
        {
            if (filelog != NULL)
                fclose(filelog);
            state = SELECT_USER;
            return HOME;
        }
    }
}
